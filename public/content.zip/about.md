---
date: ""
author: "Qprop"
title: About
---

At times when am busy with daily task or basically seated under a tree borrowing from my mentor Isaac Newton, always waiting for something to fall. Hopeful to squeal Eureka.

> **Mental journeys shuttling between utopia, dystopia and bordering paranoia.**

I have been fiddling about the idea of a blog. Nothing fancy just my own space where I pour my thoughts, musings, perturbation and amusements. Not really following the crowd to get viewership or readership, just something that would spark interest in like minded individuals, with queer mental visions and processing on going. 

This queer is not the vile one but the ones that transgress when you having conversation with someone and your mind wonders away to the concept of breathing and how natural that comes. How the being is able to be alive with the dependency on non inert gas, with reflex of the organs and involuntary action of muscles causing the lungs to push out and in.