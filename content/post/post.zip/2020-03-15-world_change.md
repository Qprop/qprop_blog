---
title: "The time for pivotal world change is here"
date: 2020-03-15T02:01:58+05:30
description: "There is a silver lining in every cloud, taking the back seat and analysing situation provides perspective. Lets you peer through different lenses meticulously sifting and searching not leting any thing cloud your judgement."
tags: ["Random", "World"]
---



There is a silver lining in every cloud, taking the back seat and analysing situation provides perspective. Lets you peer through different lenses meticulously sifting and searching not leting any thing cloud your judgement.
Four months since first cases become globally public in Wuhan China, the spread of the now code named virus COVID-19 continues unabeited. 
The exponential spread has created a lot of conversation across various forms of media. Some claiming it is being blown out of propotion compared to other virus in the past decade nameing a few Evian flu, Swine flu, SAR, MARS amongst others did not receive such attention.
Different sources claiming this was manufactured from somewhere and has now blown out of hand.

The full effect is yet to be predicated, we had foreseen such happenings in the future. To be honest nobody expected it to be in their lifetime. Ask and you  would be told global warming was an immediate existential threat than any virus, seeing that it has been on our headlines for sometime now.
Am sure some doomsday glorifiers are somewhere smiling and glotting to the fact it seems they were right.

Though I would like to change my focus not on the material matter of the virus rather the eventual effect it will have on different spheres of the new world. The impact it will have on `technology`, `society` and `politics`.
Let me absolve myself from being termed as an expert or technocrat in matters futuristic, my point of view is rather from a different pair of naive curious eye similar to that of a child discovering the tastes of fruits, vegetables and spices.

## Technology Change
_____________________
 
Development in this area has been magnanimus and not comparable to any other industry. It is as if when you sleep you wake up with a new marvel. When you thought we were looking for smaller phones sizes when we moved from big basic phones of the late and early 90's to now looking at bigger screen phones talking of folderable screens and on average the current screen size of phones being manufactered at around 5.

Now we have the opportunity to put to test autonomous technology, role out to production the various teasers and prototypes we have been glued to the internet seeing.
Time for self-driving cars now to hit the road running at full capacity. This requiring relaxing of regulation on self-driving cars.
We need now more than ever to jump on to that taxi and have not to worry about infecting or getting infected by the driver. The EV(Electronic Vehicle) could be used to do delivery, with customers picking up their purchase at the comfort of their parking.

Robots clearly now can start replacing some of us as we work from home controlling the robots. Let them do the heavy lifting the walking and dispensing were need be. Probably it is there time now to come to the fore and take charge in the repeatative continuous work flow.

Let the reing of the smart devices and smart homes rule. Interconnect all the household gadgets from the smart watches that take our health statistics, to smart AC regulating the temparatures and detecting changes. 
Why not let the smart phone automatically call the ambulance or emergency response for you. Anyway I believe as we self quarantince we do not want to be a danger to the ones we love most family. 


## Social Change
_____________________

Inevitability of social and cultural changes are part of us being here on the fourth planet away from the sun. 
We now need to change our eating dynamics from either how we eat and what we eat. How we eat, move from raw food to at least cooked food, reduce the level of microbes that inhabit this environments. This will be a tough and hard call but we will need to make it.

What we eat, we have made it hard for both the flora and fauna to flourish in there natural setting. For this we can no longer expect to feed on them without repurcasion. What we are replinishing with as food is now mutating due to the pollution and use of synthetic chemicals.
Effect is now but vaguely showing.

Might it be that we are now at a plateau, with cities having reached their ultimate size of population. Urban migration will need to be refocused and looked at either through creation of other cities with infrasture to support larger population. Or probably what about reducing distances by having many peripheral towns with shorter commutes, with adequeate infrasture capabilities.

## Political change
_____________________

Individualism and statehood, needs redefinition and adjustment. Need for coming together required more than ever, what happens in the west is not having impact in the east vice versa. 
Globalisation in as much as it creates the problems we now face but could offer solution as well to this problem and more.
More diverse people providing technical knowledge, sharing age old wisdoms are offering the much needed help that is being sort after.


>> All in all this is the time for change, the tipping point is hear. 22nd century is now experiencing pivotal escalations and maybe this is it. The next generation will probably here of the achievements or failures of this point in time. They shall be our judge as we make history for the future.
>> Our battle is now set, resilience effort and braveity is needed. Take action, take the risk we do not know what is coming but we can try steer ourselves to a direction we would want.




