---
title: "Tragedy of commons CovID-19 case"
date: 2020-03-30T02:01:58+05:30
description: "The numerous empty shelves we have witnessed across the various countries in the supermarkets is really a spectacal. 
At first you would think it is black friday at the start of the year all over."
tags: ["Random"]
---


The numerous empty shelves we have witnessed across the various countries in the supermarkets is really a spectacal. 
At first you would think it is black friday at the start of the year all over.
But no the jostling and hustling each other over tissue paper was not because of great offers.
On slaught of probable lock down after what we have witnessed in China, might have caused a scare.
Neanderthal being in us kicked in, the animal instinct the quick impulisive brain took over, in what Daniel Kahneman book `Thinking, Fast and Slow` terms as the first system.
The thought that we might lack, made every rational thinking not make sense at all. We were quick to race to the supermarkets and finish all the stocks in there.


For some who are fortunate enough to be still alive and remember the second world war in the 40's, add to this the cold war in the 60's. It is said that they had to stock piles of all necessities, the era of bunkers. 
Nuclear war was an eminent threat and a fact to live with. Thinking about it apart from the bunkers the threat is still alive and fairly so, if the events of 2019 with north korea and beginning of the year 2020 bombing of Iranian's chief motorcade which had fatalities.
I do understand then why they needed to prepare for any eventuallity I wouldn't blame them, most of them were sons, daughters or even fast hand people to experience the 1st world war.


My interest though is geared towards an economic threory which was heavily promoted by `Garret Hardin in 1968` the **tragedy of commons**. 
In summary it is about how individuals with a common shared resource ultimately independenly through selfishness deplete the common resource they shared.
Theorised based on the landowners(Lords) and tenant(commoner) system of the UK. Where if the tenants were given a shared field to grazing land. Quickly everyone would bring in their herds thus creating a rush use of the scarce resource.
Before they know it, the whole grazing land has been finished and they can no longer graze.
Had they controlled the utilization of the resource and apportioned it apopriately they would have been able to use one side as the other side recorvers. Having a full proof eco system. 
To save you the trouble here is a [link](https://en.wikipedia.org/wiki/Tragedy_of_the_commons) for your further reading and internerlizing.


This theory was originally brought to fore in 1833 and how it appllies to us some 180 years later is fascinating.
May be if we remembered that this is a resource that will need replenishing and should be shared. 
We will not panic and go stock out the supermarkets.

