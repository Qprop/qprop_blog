---
title: "City of Saints & Thieves by Natalie C Anderson"
date: 2020-05-28T02:01:58+05:30
description: "From the fictional city of Sangui all the way to Kasisi. Murder revenge theft and truth"
tags: ["Book Review","Reading List"]
---

> ![City of Saints & Thieves](https://www.nataliecanderson.com/uploads/1/8/9/6/18964685/published/anderson-citysaintsthieves-72016-3.jpg?1482223897) 



*Fiction*

Thrilling fiction of a young girl Tina. Set out to revenge for the murder of her mother, be the justice she feels she deserve. Everything is set and in motion her plan is locked and loaded.
The changes she has experienced, the skills she has acquired has posed her as the best riffraff in the Gooondas gang. 
Her nimble and agile fingers and stature makes entry and exit undetected when undertaking missions. She is an asset to the banditry and ruthless vagabonds of the street.
With names like Bug Eye lead of the gang and Ketchup his brother. Ruthless Mr.Omoko the commander of the thieving gang.

The quest for truth leads Tina, to the abyss that was the origin of her mother. The town of Kasisi in DRC. Where militias are exploiting and terrorizing the mining region. Death, rape and violence are leaving villages scared.

Tina's mum was one of them. Her escape to Sangui and protection by Mr. Greyhill has led in advertently to her death. Tina needs to revenge and protect her sister Kiki.

Revenge blood for blood.


*My thoughts*

Plot and setting are nice, traces of Nairobi and Mombasa in the stroyline makes it even more familiar.
Backdrop of a city with divided lines between the have and the have not is very clear.

