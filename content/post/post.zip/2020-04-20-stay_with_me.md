---
title: "Stay with me - Ayobami Adebayo"
date: 2020-04-20T02:01:58+05:30
description: "Setup in the late 80's to 90's Nigeria backdrop, we are introduced to Yejide wife to Akin. Who are the proverbial love at first sight couple."
tags: ["Book Review","Reading List"]
---


*Fiction*

> I was not sleepy so midnight of 5th April I start reading to push the hours before slumber kicks in. 
> Woe unto me I end up 8 hours later having not have slept but read the book through out the night, loving the story line.




Setup in the late 80's to 90's Nigeria backdrop, we are introduced to Yejide wife to Akin. Who are the proverbial love at first sight couple.
But the intrigues that underpins their marriage have a shaky foundation. Four years without blessings of additional member of the family is causing a strain to the couple especially to Yejide.
This calls for intervention from both extended families, forcing Yejide to be become first wife as Akin is handed a second wife by the mother.
Shaking an already dicey situation even further.

Akin decides to be scrupulous, he hatches a plan that includes his brother. Ends up having Yejide pregnant and in the processing unfortunately losing his second wife, with whom he did not have any feelings at all for.

As fate would have it their daughter does not survive beyond 5 months of infancy.
Again the betrayals and deceit take center stage and they are blessed with a boy, only to be diagnosed with sickle cell disease.
Further medical test confirm that Akin is not a carrier of the gene, raising a lot of suspicion.

Unfortunately they end up losing their son, which leaves Yejide jaded and forlorn. Though she is blessed with another third child a girl.
The tests are not good and is also diagnosed with sickle cell disease.
Throwing her into a state of no longer getting involved with the daughter eventually she separates and moves away. Not knowing whether her daughter dies or not. She is invited to Akin's fathers burial and she will use the opportunity how things happened with her daughter Rotimi.

Following the intrigues of the various families involved plot twist and turns.

Tackling issues from stigma for young couples without kids, polygamy and impotence.


