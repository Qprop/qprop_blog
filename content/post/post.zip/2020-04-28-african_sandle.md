---
title: "Adventure with Kanduyi"
date: 2020-04-28T02:01:58+05:30
description: "
The feeling of soft aerated, oiled and moist feet are quintessential heaven bless for the feet.
Being closed up suffocated and squeezed in side closed shoes all day, the relief you get once you remove the pair of closed shoes is non comparable."
tags: [Random]
---


*Fiction\Factual*

The feeling of soft aerated, oiled and moist feet are quintessential heaven bless for the feet.
Being closed up suffocated and squeezed in side closed shoes all day, the relief you get once you remove the pair of closed shoes is non comparable. Though scratching inside your ears to relieve the itchy feeling comes close.

Toddler moments when they get to see their parents after a long day experience it is when untying my shoelace. The anticipation my feet go through is nerve racking. 

Removing your feet inside the shoe is a kin to warm water bath on a cold day. A bash filled momentous crescendo of elatedness. Pulling out the socks and throwing it away without any care in the world where it will land. 
Answers the question why you find socks strewn all over the place in a bachelors man cave not that match changes when you are married, apart from the hole drilling eye you get from your partner for you to realize that you have done something wrong.
Hits you a few seconds later what it is and that is when you glorious symphony stops albeit temporarily.

Slipping your feet methodically an engineering maneuver you would add, into the African pair of sandals.
Let me explain the African pair of sandal, like none other is made of interesting materials.
Recycling is core of the process, the sole is made from worn out car tires. Pristinely cut to fit a shoe sole. Sandle strap come in various variants either continuation of slices of the tires smoothened by sand paper. Or you get straps made of light leather, with it is genuine or not that is not the point.

During my travel days back in 2014, I got myself a souvenir at the border point of Kenya and Uganda. Light perfect finish trimmed pair of African sandals, this was not my first pair of African sandals in fact had it not been that the original sandals I was wearing that time got cut doubt I would have bought the pair.
The souvenir part then can just be an excuse.

Oooh boy! The sandals were so comfortable and would mark a love relationship that no other pair has experienced.
I would were it everywhere literally they were my de facto look, when not dressed officially. 
They would accompany me on any trip I would be making. The first to be packed if I am not wearing them.

It would be my companion on my central Kenya tour for a work function. It would get to see the green scenary of Meru town, mystic forgotten town of Muranga. The town of Kerugoya which I would always confuse as the town of Kirinyaga, tad bit of information there isn't any town known as Kirinyaga.

The freezing cold facing Mt. Kenya in Nyeri. I would still walk the path with my African pair of sandals bought on the other side of the country in Malaba, Busia county.
I did not get to give the pair a name but had it gotten a name, probably I would have baptised it Kanduyi. Small town in Bungoma. I liked the name Kanduyi.


Kanduyi would once again accompany me to Kinshasa DRC the land of Lingala. Though, I think I missed it, since am no fan of Lingala music. For the sake of supporting my masculinity and African machoness we shall pretend am an avid lover of Lingala music.
Before then for me it was just a genre of music, shook on me it is a language spoken in the western part of DRC very predominantly second to French. 
Walked with me in through the big divide that is Kinshasa on one hand you would see latest flashy cars and then just behind it a worn out old 1980's Toyota. With wanting body work repair.
As with cars so were the buildings, fading walls with green molding growing on old architectured building telling of days gone and how opulent this place might have been. 
On the other side of the road you would see new buildings, modern exterior cladding and so attractive.

Kanduyi the sandals would be part of my journey to Lumbumbashi, the extreme eastern DRC headquarters. The name is mentioned a lot in Lingala music which I had when I was growing up back in Kenya.
Familiarity in the language the speak Kiswahili, though with different sentence structure missing adverbs and adjectives but none the less a language I can speak.
This made me feel at home in a foreign land.

Kanduyi saw me travel to the interior of Mbuji Mayi the mining region and center of diamonds in DRC. 
Similar to Kinshasa the facade tells of a history of richness in wealth, now it is just a ghost of its former self and glory. There is hope though that one day the revival of the mining industry will take place.
To Kananga we went together, deep in central DRC. Rural life, with no electricity but make shift distribution of electricity by local vendors. With whom they had generators and distributing electricity to the households for lighting the houses and charging their phones.

Kanduyi would be by my side as I made the 100KM or so trip from Dar Salam in Tanzania to Tanga. Change of beautiful sceneries, with perfectly built highway. No potholes at all, drivers adhering to speed limits when driving through towns.
Tanga bordered the Indian ocean, though I did not get a chance to walk along the beach. I could see the tides from my hotel window.

5 years later Kanduyi was unceremoniously thrown away. There was mention that it was very old and lacked any semblance of being a sandal.
If only they knew the history that Kanduyi had made the places and remote areas it had visited.
The comfort it gave when your 30,000 feet in the air in a pressurised tube on a 5 hour journey, knowing that feet swells will not be part of your experiences.
Kanduyi had been there when I was rained on in the middle of Mbuji Mayi trying to figure out how I would reach my dingy hotel 15KM away. Hoping onto a motorbike and making the precarious journey back getting soaked in rain with every roaring of the 200CC engine motorbike.

Kanduyi has not gotten a replacement yet but the history we shared is etched into my mind. A history shared with anyone willing to listen, the history of an African sandal.
The miles it has done, the joy and sadness it has shared with its companion.

Its story will still be told.





